import{c as o}from"./createLucideIcon-9764001c.js";const e=o("ChevronDownIcon",[["polyline",{points:"6 9 12 15 18 9",key:"1do0m2"}]]);export{e as C};
