import{_ as e}from"./index-821a6bc7.js";const t={};function n(r,_){return null}const s=e(t,[["render",n]]);export{s as default};
