import{_ as e}from"./index-f07c188b.js";const t={};function n(r,_){return null}const s=e(t,[["render",n]]);export{s as default};
