import{c}from"./createLucideIcon-74044a99.js";const r=c("SearchIcon",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["line",{x1:"21",x2:"16.65",y1:"21",y2:"16.65",key:"13gj7c"}]]);export{r as S};
