import{_ as e}from"./index-edbe1eb9.js";const t={};function n(r,_){return null}const s=e(t,[["render",n]]);export{s as default};
