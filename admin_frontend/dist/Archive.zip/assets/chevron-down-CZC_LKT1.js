import{c as o}from"./createLucideIcon-CUtFUaqZ.js";/**
 * @license lucide-vue-next v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=o("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{n as C};
//# sourceMappingURL=chevron-down-CZC_LKT1.js.map
