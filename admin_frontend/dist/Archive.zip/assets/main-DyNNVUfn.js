import{_ as o,r,c as n,o as t,d as c}from"./index-H5beSXt9.js";const s={};function a(_,i){const e=r("router-view");return t(),n("div",null,[c(e)])}const m=o(s,[["render",a]]);export{m as default};
//# sourceMappingURL=main-DyNNVUfn.js.map
