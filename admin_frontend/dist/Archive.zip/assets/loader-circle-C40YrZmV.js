import{c as e}from"./createLucideIcon-DKNoFLvU.js";/**
 * @license lucide-vue-next v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=e("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);export{c as L};
//# sourceMappingURL=loader-circle-C40YrZmV.js.map
