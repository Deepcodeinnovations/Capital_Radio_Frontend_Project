import{c as o}from"./createLucideIcon-CUtFUaqZ.js";/**
 * @license lucide-vue-next v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=o("play",[["polygon",{points:"6 3 20 12 6 21 6 3",key:"1oa8hb"}]]);export{c as P};
//# sourceMappingURL=play-C0K9b7Yb.js.map
