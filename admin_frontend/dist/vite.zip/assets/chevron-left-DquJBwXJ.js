import{c as e}from"./createLucideIcon-BvNgPl9c.js";/**
 * @license lucide-vue-next v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const t=e("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);export{t as C};
//# sourceMappingURL=chevron-left-DquJBwXJ.js.map
