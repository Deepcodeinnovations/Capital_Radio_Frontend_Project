import{c as t}from"./createLucideIcon-Bsy_Af9M.js";/**
 * @license lucide-vue-next v0.511.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const h=t("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);export{h as C};
//# sourceMappingURL=chevron-right-DGbfCVbM.js.map
