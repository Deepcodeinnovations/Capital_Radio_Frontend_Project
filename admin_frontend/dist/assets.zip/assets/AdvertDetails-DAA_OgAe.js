import{_ as t,c as r,o as s,b as n}from"./index-B7q1ptPU.js";const o={};function a(c,e){return s(),r("div",null,e[0]||(e[0]=[n("h1",null,"Adverts",-1)]))}const d=t(o,[["render",a]]);export{d as default};
//# sourceMappingURL=AdvertDetails-DAA_OgAe.js.map
