import{_ as o,r,c as n,o as t,d as c}from"./index-D-vGU9A5.js";const s={};function a(_,i){const e=r("router-view");return t(),n("div",null,[c(e)])}const m=o(s,[["render",a]]);export{m as default};
//# sourceMappingURL=main-F_2z-Qc_.js.map
