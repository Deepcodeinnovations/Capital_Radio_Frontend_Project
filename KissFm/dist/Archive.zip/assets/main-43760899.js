import{_ as o,i as r,g as n,b as t}from"./index-8ff82c37.js";const c={};function s(_,a){const e=n("router-view");return t(),r(e)}const f=o(c,[["render",s]]);export{f as default};
