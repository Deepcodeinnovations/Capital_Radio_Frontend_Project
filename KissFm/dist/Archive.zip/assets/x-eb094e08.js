import{c as e}from"./createLucideIcon-3ab7f00b.js";const o=e("XIcon",[["line",{x1:"18",x2:"6",y1:"6",y2:"18",key:"15jfxm"}],["line",{x1:"6",x2:"18",y1:"6",y2:"18",key:"d1lma3"}]]);export{o as X};
