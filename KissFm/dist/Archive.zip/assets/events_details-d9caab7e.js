import{_ as e}from"./index-c52aa19e.js";const t={};function n(r,_){return null}const s=e(t,[["render",n]]);export{s as default};
