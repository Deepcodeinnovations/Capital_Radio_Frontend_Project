import{c as o}from"./createLucideIcon-45e0e77c.js";const a=o("PlayIcon",[["polygon",{points:"5 3 19 12 5 21 5 3",key:"191637"}]]);export{a as P};
