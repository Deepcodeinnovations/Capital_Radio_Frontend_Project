import{_ as e}from"./index-110393c0.js";const t={};function n(r,_){return null}const s=e(t,[["render",n]]);export{s as default};
