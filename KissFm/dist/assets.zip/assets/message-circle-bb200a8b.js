import{c as e}from"./createLucideIcon-45e0e77c.js";const a=e("MessageCircleIcon",[["path",{d:"m3 21 1.9-5.7a8.5 8.5 0 1 1 3.8 3.8z",key:"v2veuj"}]]);export{a as M};
