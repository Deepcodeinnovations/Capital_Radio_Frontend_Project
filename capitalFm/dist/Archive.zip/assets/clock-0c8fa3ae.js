import{c}from"./createLucideIcon-dde33caf.js";const e=c("ClockIcon",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]]);export{e as C};
