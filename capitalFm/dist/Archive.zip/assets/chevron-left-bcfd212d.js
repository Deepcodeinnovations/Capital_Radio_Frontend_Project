import{c as e}from"./createLucideIcon-dde33caf.js";const n=e("ChevronLeftIcon",[["polyline",{points:"15 18 9 12 15 6",key:"kvxz59"}]]);export{n as C};
