import{c as o}from"./createLucideIcon-dde33caf.js";const t=o("ChevronRightIcon",[["polyline",{points:"9 18 15 12 9 6",key:"1rtp27"}]]);export{t as C};
