import{_ as o,m as r,r as n,o as t}from"./index-3bdb0cb8.js";const c={};function s(_,a){const e=n("router-view");return t(),r(e)}const f=o(c,[["render",s]]);export{f as default};
