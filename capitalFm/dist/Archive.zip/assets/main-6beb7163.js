import{_ as o,k as r,f as n,o as t}from"./index-d4daf8ef.js";const c={};function s(_,a){const e=n("router-view");return t(),r(e)}const i=o(c,[["render",s]]);export{i as default};
