import{_ as e}from"./index-d4daf8ef.js";const t={};function n(r,_){return null}const s=e(t,[["render",n]]);export{s as default};
